package com.example.tradepilot

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button

class MainActivity : Activity() {
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(2), dp(6), dp(2), dp(6))
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.rgb(13, 18, 30)
        val panel = Color.rgb(24, 31, 45)
        val white = Color.WHITE
        val muted = Color.rgb(160, 173, 193)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(28), dp(20), dp(20)) }
        root.addView(text("TRADEPILOT", 22f, white, true))
        root.addView(text("Markets dashboard · Prototype", 13f, muted))
        root.addView(text("Portfolio balance", 14f, muted))
        root.addView(text("₹100.00", 34f, white, true))
        root.addView(text("Demo funds only — no real trades", 12f, Color.rgb(255,190,90)))
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); setBackgroundColor(panel) }
        card.addView(text("MARKET STATUS", 12f, muted, true))
        card.addView(text("Live market data is not connected", 18f, white, true))
        card.addView(text("Broker account: Not connected\nQuotes: Not connected\nStrategy engine: Disabled", 14f, muted))
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        root.addView(text("Trading controls", 18f, white, true).apply { setPadding(0, dp(18), 0, dp(4)) })
        val stop = Button(this).apply { text = "STOP ALL TRADING"; isEnabled = false }
        root.addView(stop)
        root.addView(text("Live trading remains disabled until a broker integration, backend security, account authorization, and required regulatory checks are completed.", 13f, muted))
        root.addView(text("Recent activity", 18f, white, true).apply { setPadding(0, dp(14), 0, dp(4)) })
        root.addView(text("No trades yet.\n\nThis starter app is a UI prototype. It does not contain a market feed, trading signals, broker credentials, or order execution.", 14f, muted))
        setContentView(root)
    }
}
